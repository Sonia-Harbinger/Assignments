//TASK 1
let name = "Sonia Sahu"; //my name
let age = 22; //my age
let isStudent = true; //I am a student hence true



//TASK 2
let num1 = 30; //first number
let num2 = 50; //second number
let sum = num1 + num2; //sum of two numbers
let difference = num1 - num2; //difference of two numbers
let product = num1 * num2; //product of two numbers
let quotient = num1 / num2; //quotient of two numbers





//TASK 3

let firstName = "Sonia"; //my first name
let lastName = "Sahu"; //my last name
let occupation = "Trainee Software Engineer"; //my occupation
let fullName = firstName + " " + lastName; //concatenating first name and last name

let bio =
  " My name is " +
  fullName +
  "." +
  " I am working as a " +
  occupation +
  "at Harbinger Groups."; //concatenating full name and occupation in a sentence.





//TASK 4
console.log("Name:" + name, "Age: " + age, "Are you a student? " + isStudent); //displaying name, age and student status
console.log("Sum is :" + sum); //displaying sum
console.log("Difference is: " + difference); //displaying difference
console.log("Product is : " + product); //displaying product
console.log("Quotient is : " + quotient); //displaying quotient
console.log("Full Name:" + fullName); //displaying full name
console.log("BIO:" + bio); // displaying bio






//Bonus Task
// Create a variable named "birthYear" and initialize it with your birth year.
// Calculate your approximate age using the current year and the "birthYear" variable.
// Display the calculated age using console.log().

var birthYear = 2001; //my birth year
let myAge = 2025 - birthYear; //calculating age
console.log("Age: " + myAge); //displaying age
