///<reference path="typescript_assignment.ts" />

const sums = MathOperations.add(10, 5);
console.log(sums); // Output: 15

const difference = MathOperations.subtract(10, 5);
console.log(difference); // Output: 5